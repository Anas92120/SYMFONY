<?php

namespace App\Service;


class Service
{

	private $service;

    public function monService(){
      
    }

    public function __construct($service){
    	$this->service = $service;
    }
    
}
