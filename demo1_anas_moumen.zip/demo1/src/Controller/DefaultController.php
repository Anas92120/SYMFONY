<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class DefaultController extends AbstractController
{

    public function accueil(Request $request): Response
    {
        $profil = $request->get('profil');
        $login = $request->get('login');

        return $this->json([
            'message' => 'Voici mon profil : ' . $profil . ' et mon login : ' . $login ,
            'path' => 'src/Controller/DefaultController.php',
        ]);
    }

    public function index(): Response
    {
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/DefaultController.php',
        ]);
    }
}
