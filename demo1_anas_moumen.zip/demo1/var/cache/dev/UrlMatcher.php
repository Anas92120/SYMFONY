<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/connexion' => [[['_route' => 'formulaire_connexion', '_controller' => 'App\\Controller\\FormulaireController::connexion'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/accueil(?:/([a-zA-Z]+)(?:/([^/]++))?)?(*:81)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        81 => [
            [['_route' => 'default_accueil', 'profil' => 'invite', 'login' => 'anonymous', '_controller' => 'App\\Controller\\DefaultController::accueil'], ['profil', 'login'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
